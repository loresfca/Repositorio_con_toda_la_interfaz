//
//  ControladorBuscaTuCuadrante.swift
//  SwiftMapKit
//
//  Created by Versatran on 3/23/16.
//  Copyright © 2016 Tec de Monterrey. All rights reserved.
//

import WatchKit

class ControladorBuscaTuCuadrante: UIViewController {

}
